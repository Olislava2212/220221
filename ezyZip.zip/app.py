from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Замените на случайный секретный ключ

# Декоратор для проверки аутентификации
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Пожалуйста, войдите в систему для доступа к этой странице.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Инициализация базы данных
def init_db():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    # Создание таблицы пользователей
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL)''')
                  
    # Создание таблиц для финансовых данных с привязкой к пользователю
    c.execute('''CREATE TABLE IF NOT EXISTS income
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER NOT NULL,
                  amount REAL NOT NULL,
                  source TEXT NOT NULL,
                  date TEXT NOT NULL,
                  description TEXT,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
                  
    c.execute('''CREATE TABLE IF NOT EXISTS expenses
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER NOT NULL,
                  amount REAL NOT NULL,
                  category TEXT NOT NULL,
                  date TEXT NOT NULL,
                  description TEXT,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    conn.commit()
    conn.close()

# Регистрация пользователя
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Хешируем пароль
        hashed_password = generate_password_hash(password)
        
        # Вставляем данные в БД
        try:
            conn = sqlite3.connect('finance.db')
            c = conn.cursor()
            c.execute("INSERT INTO users (username, password) VALUES (?, ?)",
                     (username, hashed_password))
            conn.commit()
            conn.close()
            flash('Регистрация успешна!', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Это имя пользователя уже занято', 'danger')
    
    return render_template('auth/register.html')

# Вход пользователя
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = sqlite3.connect('finance.db')
        c = conn.cursor()
        c.execute("SELECT id, username, password FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        
        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['username'] = user[1]  # Сохраняем имя пользователя в сессии
            flash('Вы успешно вошли в систему!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'danger')
    
    return render_template('auth/login.html')

# Выход пользователя
@app.route('/logout')
def logout():
    session.clear()
    flash('Вы успешно вышли из системы', 'info')
    return redirect(url_for('login'))

# Главная страница (только для авторизованных)
@app.route('/')
@login_required
def index():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    # Получаем последние 5 доходов
    c.execute("""
        SELECT amount, source, date, description 
        FROM income 
        WHERE user_id = ? 
        ORDER BY date DESC 
        LIMIT 5
    """, (session['user_id'],))
    incomes = c.fetchall()
    
    # Получаем последние 5 расходов
    c.execute("""
        SELECT amount, category, date, description 
        FROM expenses 
        WHERE user_id = ? 
        ORDER BY date DESC 
        LIMIT 5
    """, (session['user_id'],))
    expenses = c.fetchall()
    
    conn.close()
    
    balance = get_balance()
    
    return render_template('index.html', 
                         balance=balance,
                         incomes=incomes,
                         expenses=expenses,
                         username=session.get('username'))

@app.route('/add_expense', methods=['GET', 'POST'])
@login_required
def add_expense():
    if request.method == 'POST':
        amount = float(request.form['amount'])
        category = request.form['category']
        description = request.form.get('description', '')
        date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))
        
        conn = sqlite3.connect('finance.db')
        c = conn.cursor()
        
        # Вставляем расход в БД
        c.execute("""INSERT INTO expenses 
                    (user_id, amount, category, date, description) 
                    VALUES (?, ?, ?, ?, ?)""",
                 (session['user_id'], amount, category, date, description))
        
        conn.commit()
        conn.close()
        flash('Расход добавлен!', 'success')
        return redirect(url_for('index'))
    
    return render_template('add_expense.html', current_date=datetime.now().strftime('%Y-%m-%d'))

# Пример для add_income:
@app.route('/add_income', methods=['GET', 'POST'])
@login_required
def add_income():
    if request.method == 'POST':
        amount = float(request.form['amount'])
        source = request.form['source']
        description = request.form.get('description', '')
        date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))
        
        conn = sqlite3.connect('finance.db')
        c = conn.cursor()
        
        # Вставляем доход в БД
        c.execute("""INSERT INTO income 
                    (user_id, amount, source, date, description) 
                    VALUES (?, ?, ?, ?, ?)""",
                 (session['user_id'], amount, source, date, description))
        
        conn.commit()
        conn.close()
        flash('Доход добавлен!', 'success')
        return redirect(url_for('index'))
    
    return render_template('add_income.html', current_date=datetime.now().strftime('%Y-%m-%d'))


# Функция получения баланса с учетом пользователя
def get_balance():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    c.execute("SELECT SUM(amount) FROM income WHERE user_id = ?", 
              (session['user_id'],))
    total_income = c.fetchone()[0] or 0
    
    c.execute("SELECT SUM(amount) FROM expenses WHERE user_id = ?", 
              (session['user_id'],))
    total_expenses = c.fetchone()[0] or 0
    
    conn.close()
    
    return total_income - total_expenses

def init_db():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    # Создание таблицы пользователей
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL)''')
                  
    # Создание таблиц для финансовых данных с привязкой к пользователю
    c.execute('''CREATE TABLE IF NOT EXISTS income
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER NOT NULL,
                  amount REAL NOT NULL,
                  source TEXT NOT NULL,
                  date TEXT NOT NULL,
                  description TEXT,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
                  
    c.execute('''CREATE TABLE IF NOT EXISTS expenses
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER NOT NULL,
                  amount REAL NOT NULL,
                  category TEXT NOT NULL,
                  date TEXT NOT NULL,
                  description TEXT,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    conn.commit()
    conn.close()

@app.route('/report')
@login_required
def report():
    conn = sqlite3.connect('finance.db')
    c = conn.cursor()
    
    # Сумма доходов
    c.execute("SELECT SUM(amount) FROM income WHERE user_id = ?", (session['user_id'],))
    total_income = c.fetchone()[0] or 0
    
    # Сумма расходов
    c.execute("SELECT SUM(amount) FROM expenses WHERE user_id = ?", (session['user_id'],))
    total_expenses = c.fetchone()[0] or 0
    
    # Доходы по источникам
    c.execute("SELECT source, SUM(amount) FROM income WHERE user_id = ? GROUP BY source", (session['user_id'],))
    income_by_source = c.fetchall()
    
    # Расходы по категориям
    c.execute("SELECT category, SUM(amount) FROM expenses WHERE user_id = ? GROUP BY category", (session['user_id'],))
    expenses_by_category = c.fetchall()
    
    conn.close()
    
    return render_template('report.html',
                         total_income=total_income,
                         total_expenses=total_expenses,
                         income_by_source=income_by_source,
                         expenses_by_category=expenses_by_category)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)


